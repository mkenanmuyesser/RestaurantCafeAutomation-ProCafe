﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace SmarterPing.Forms
{
    public class UrlItem : ListViewItem
    {
        public UrlItem(string url, bool isReachable)
        {
            Text = url;
            SubItems.Add(isReachable.ToString());
            if (isReachable)
            {
                SubItems.Add("");
                SetLastSucceeded(DateTime.Now);
            }
            else
                SubItems.Add("-");
            IsReachable = isReachable;
        }

        public string Url { get { return Text; } set { Text = value; } }

        public bool IsReachable
        {
            get { return bool.Parse(SubItems[1].Text); }
            set
            {
                SubItems[1].Text = value.ToString();
                if (value)
                {
                    SetLastSucceeded(DateTime.Now);
                    SubItems[0].ForeColor = Color.Black;
                }
                else
                    SubItems[0].ForeColor = Color.Red;
            }
        }

        public DateTime? LastSucceeded { get { return SubItems[2].Text == "-" ? (DateTime?) null : DateTime.Parse(SubItems[2].Text); } }

        public void SetLastSucceeded(DateTime? val)
        {
            if (val == null)
                SubItems[2].Text = "-";
            else
            {
                string time = val.Value.ToShortTimeString();
                if (val.Value.DayOfYear != DateTime.Now.DayOfYear)
                    time = val.ToString();
                SubItems[2].Text = time;
            }
        }
    }
}
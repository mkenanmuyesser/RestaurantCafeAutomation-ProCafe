﻿namespace SmarterPing.Forms
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsForm));
            this.ButtonOK = new System.Windows.Forms.Button();
            this.ButtonCancel = new System.Windows.Forms.Button();
            this.ProcessStatusTimer = new System.Windows.Forms.Timer(this.components);
            this.PingSiteFrequencyBox = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ApplyStartupModeButton = new System.Windows.Forms.Button();
            this.StopServiceButton = new System.Windows.Forms.Button();
            this.StartServiceButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.CurrentStatus = new System.Windows.Forms.Label();
            this.StartupModeDropdownList = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PingSiteFrequencyBox)).BeginInit();
            this.SuspendLayout();
            // 
            // ButtonOK
            // 
            this.ButtonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ButtonOK.Location = new System.Drawing.Point(214, 156);
            this.ButtonOK.Name = "ButtonOK";
            this.ButtonOK.Size = new System.Drawing.Size(75, 23);
            this.ButtonOK.TabIndex = 0;
            this.ButtonOK.Text = "OK";
            this.ButtonOK.UseVisualStyleBackColor = true;
            this.ButtonOK.Click += new System.EventHandler(this.ButtonOK_Click);
            // 
            // ButtonCancel
            // 
            this.ButtonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ButtonCancel.Location = new System.Drawing.Point(295, 156);
            this.ButtonCancel.Name = "ButtonCancel";
            this.ButtonCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonCancel.TabIndex = 1;
            this.ButtonCancel.Text = "Cancel";
            this.ButtonCancel.UseVisualStyleBackColor = true;
            this.ButtonCancel.Click += new System.EventHandler(this.ButtonCancel_Click);
            // 
            // ProcessStatusTimer
            // 
            this.ProcessStatusTimer.Enabled = true;
            this.ProcessStatusTimer.Interval = 250;
            this.ProcessStatusTimer.Tick += new System.EventHandler(this.ProcessStatusTimer_Tick);
            // 
            // PingSiteFrequencyBox
            // 
            this.PingSiteFrequencyBox.Location = new System.Drawing.Point(100, 9);
            this.PingSiteFrequencyBox.Name = "PingSiteFrequencyBox";
            this.PingSiteFrequencyBox.Size = new System.Drawing.Size(50, 20);
            this.PingSiteFrequencyBox.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(154, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "minutes (10 recommended)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Ping sites every";
            // 
            // ApplyStartupModeButton
            // 
            this.ApplyStartupModeButton.Location = new System.Drawing.Point(262, 40);
            this.ApplyStartupModeButton.Name = "ApplyStartupModeButton";
            this.ApplyStartupModeButton.Size = new System.Drawing.Size(69, 23);
            this.ApplyStartupModeButton.TabIndex = 14;
            this.ApplyStartupModeButton.Text = "Apply";
            this.ApplyStartupModeButton.UseVisualStyleBackColor = true;
            this.ApplyStartupModeButton.Click += new System.EventHandler(this.ApplyStartupModeButton_Click);
            // 
            // StopServiceButton
            // 
            this.StopServiceButton.Location = new System.Drawing.Point(181, 90);
            this.StopServiceButton.Name = "StopServiceButton";
            this.StopServiceButton.Size = new System.Drawing.Size(75, 23);
            this.StopServiceButton.TabIndex = 13;
            this.StopServiceButton.Text = "Stop";
            this.StopServiceButton.UseVisualStyleBackColor = true;
            this.StopServiceButton.Click += new System.EventHandler(this.StopServiceButton_Click);
            // 
            // StartServiceButton
            // 
            this.StartServiceButton.Location = new System.Drawing.Point(100, 90);
            this.StartServiceButton.Name = "StartServiceButton";
            this.StartServiceButton.Size = new System.Drawing.Size(75, 23);
            this.StartServiceButton.TabIndex = 12;
            this.StartServiceButton.Text = "Start";
            this.StartServiceButton.UseVisualStyleBackColor = true;
            this.StartServiceButton.Click += new System.EventHandler(this.StartServiceButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Current State";
            // 
            // CurrentStatus
            // 
            this.CurrentStatus.AutoSize = true;
            this.CurrentStatus.Location = new System.Drawing.Point(97, 74);
            this.CurrentStatus.Name = "CurrentStatus";
            this.CurrentStatus.Size = new System.Drawing.Size(47, 13);
            this.CurrentStatus.TabIndex = 10;
            this.CurrentStatus.Text = "Running";
            // 
            // StartupModeDropdownList
            // 
            this.StartupModeDropdownList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StartupModeDropdownList.FormattingEnabled = true;
            this.StartupModeDropdownList.Items.AddRange(new object[] {
            "Automatic",
            "Manual",
            "Disabled"});
            this.StartupModeDropdownList.Location = new System.Drawing.Point(100, 41);
            this.StartupModeDropdownList.Name = "StartupModeDropdownList";
            this.StartupModeDropdownList.Size = new System.Drawing.Size(156, 21);
            this.StartupModeDropdownList.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Startup Mode";
            // 
            // SettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.ButtonCancel;
            this.ClientSize = new System.Drawing.Size(379, 188);
            this.Controls.Add(this.ApplyStartupModeButton);
            this.Controls.Add(this.StopServiceButton);
            this.Controls.Add(this.StartServiceButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CurrentStatus);
            this.Controls.Add(this.StartupModeDropdownList);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PingSiteFrequencyBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ButtonOK);
            this.Controls.Add(this.ButtonCancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SettingsForm";
            this.Padding = new System.Windows.Forms.Padding(6);
            this.ShowInTaskbar = false;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.SettingsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PingSiteFrequencyBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonOK;
        private System.Windows.Forms.Button ButtonCancel;
        private System.Windows.Forms.Timer ProcessStatusTimer;
        private System.Windows.Forms.NumericUpDown PingSiteFrequencyBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ApplyStartupModeButton;
        private System.Windows.Forms.Button StopServiceButton;
        private System.Windows.Forms.Button StartServiceButton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label CurrentStatus;
        private System.Windows.Forms.ComboBox StartupModeDropdownList;
        private System.Windows.Forms.Label label4;
    }
}
﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Security.Permissions;
using System.ServiceProcess;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using SmarterPing.Framework;
using SmarterPing.Interfaces;

namespace SmarterPing.Forms
{
    public partial class MainForm : Form
    {
        private bool ClearNow;
        private bool ClearNow2;
        public List<UrlResult> dtURLs;
        public object dtURLsLocker = new object();
        private Thread thdGetURLs;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Start();

            thdGetURLs = new Thread(GetURLsLoop) {IsBackground = true, Name = "GetURLsLoop"};
            thdGetURLs.Start();
            UrlListView_Resize(this, null);

            // If service not installed, install it
            var f = new RegistryPermission(RegistryPermissionAccess.AllAccess, @"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SmarterPing");
            var rk = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\SmarterPing");
            if (rk == null)
            {
                if (MessageBox.Show("The SmarterPing Service must be installed before SmarterPing can function correctly.\r\n\r\n" +
                                    "Do you wish to install it now?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    WindowsServiceInstaller.RuntimeInstall<SmarterPingServiceImplementation>();
                }
            }

            // If service installed but not running, start it
            ServiceController service = null;
            try
            {
                service = new ServiceController("SmarterPing");
                if (service.Status == ServiceControllerStatus.Paused ||
                    service.Status == ServiceControllerStatus.Stopped)
                    service.Start();
            }
            catch
            {
                MessageBox.Show("There was an error trying to start the service SmarterPing.");
            }
            finally
            {
                if (service != null)
                {
                    service.Close();
                    service.Dispose();
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm = new SettingsForm();
            if (frm.ShowDialog() != DialogResult.OK)
                return;
            ClearNow = true;
            UrlListView.Items.Clear();
            RedrawElements();
        }

        private void contentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("http://help.smartertools.com/SmarterPing/v2/");
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("http://help.smartertools.com/SmarterPing/v2/Topics/Misc/Search.aspx");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            RedrawElements();
        }

        private void RedrawElements()
        {
            bool updated = false;

            try
            {
                lock (dtURLsLocker)
                {
                    if (ClearNow2)
                    {
                        UrlListView.Items.Clear();
                        ClearNow2 = false;
                    }

                    if (dtURLs != null)
                    {
                        foreach (var row in dtURLs)
                        {
                            bool found = false;
                            foreach (UrlItem lvi in UrlListView.Items)
                            {
                                if (!lvi.Url.Trim().Equals(row.Url.Trim()))
                                    continue;
                                found = true;
                                if (updated || (lvi.LastSucceeded == row.LastPing && row.LastPingSuceeded == lvi.IsReachable))
                                    continue;
                                updated = true;
                                UrlListView.BeginUpdate();
                                lvi.IsReachable = row.LastPingSuceeded;
                                lvi.SetLastSucceeded(row.LastPing);
                            }
                            if (found)
                                continue;

                            var lvi2 = new UrlItem(row.Url, row.LastPingSuceeded);
                            if (!updated)
                            {
                                updated = true;
                                UrlListView.BeginUpdate();
                            }
                            lvi2.SetLastSucceeded(row.LastPing);
                            UrlListView.Items.Add(lvi2);
                        }
                    }
                    else
                    {
                        updated = true;
                        UrlListView.BeginUpdate();
                        UrlListView.Items.Clear();
                    }
                }
            }
            catch
            {
            }
            finally
            {
                if (updated)
                    UrlListView.EndUpdate();
            }
        }

        private void GetURLsLoop()
        {
            while (true)
            {
                try
                {
                    string urlRemoting = "tcp://localhost:50004/SmarterPingFunction";
                    var funcs = (ISmarterPingFunctions) (Activator.GetObject(typeof (ISmarterPingFunctions), urlRemoting));
                    var props = ChannelServices.GetChannelSinkProperties(funcs);
                    props["timeout"] = 60 /*sec*/*1000 /*ms*/;
                    var result = funcs.GetUrls();

                    if (result.FunctionSucceeded)
                    {
                        lock (dtURLsLocker)
                        {
                            dtURLs = result.Urls;
                            if (ClearNow)
                            {
                                ClearNow = false;
                                ClearNow2 = true;
                            }
                        }
                    }
                }
                catch
                {
                }

                Thread.Sleep(5000);
            }
        }

        private void UrlListView_Resize(object sender, EventArgs e)
        {
            UrlListView.Columns[0].Width = UrlListView.Width - UrlListView.Columns[1].Width - UrlListView.Columns[2].Width - 4;
        }

        private void ManageUrlsButton_Click(object sender, EventArgs e)
        {
            var frm = new UrlsForm();
            if (frm.ShowDialog() != DialogResult.OK)
                return;
            ClearNow = true;
            UrlListView.Items.Clear();
            RedrawElements();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var a = new AboutForm();
            a.ShowDialog();
        }
    }
}
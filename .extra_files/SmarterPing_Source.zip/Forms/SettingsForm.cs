﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Security.Permissions;
using System.ServiceProcess;
using System.Windows.Forms;
using Microsoft.Win32;
using SmarterPing.Interfaces;

namespace SmarterPing.Forms
{
    public partial class SettingsForm : Form
    {
        protected const string RemotingUrl = "tcp://localhost:50004/SmarterPingFunction";

        public SettingsForm()
        {
            InitializeComponent();
        }

        public int IntervalMinutes { get { return (int) PingSiteFrequencyBox.Value; } }

        private void SettingsForm_Load(object sender, EventArgs e)
        {
            PingSiteFrequencyBox.Value = 10;
            PingSiteFrequencyBox.Focus();

            try
            {
                var funcs = (ISmarterPingFunctions) (Activator.GetObject(typeof (ISmarterPingFunctions), RemotingUrl));
                var props = ChannelServices.GetChannelSinkProperties(funcs);
                props["timeout"] = 30 /*sec*/*1000 /*ms*/;
                var result = funcs.GetVariable("interval_minutes");
                int temp;
                if (int.TryParse(result.ResultMessage, out temp))
                    PingSiteFrequencyBox.Value = temp;

                var f = new RegistryPermission(RegistryPermissionAccess.AllAccess, @"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SmarterPing");
                var rk = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\SmarterPing");
                string startType = rk.GetValue("Start", 0).ToString();
                switch (startType)
                {
                    case "0":
                        StartupModeDropdownList.SelectedIndex = 1;
                        break;
                    case "2":
                        StartupModeDropdownList.SelectedIndex = 0;
                        break;
                    case "3":
                        StartupModeDropdownList.SelectedIndex = 1;
                        break;
                    case "4":
                        StartupModeDropdownList.SelectedIndex = 2;
                        break;
                }
                rk.Close();
            }
            catch
            {
                MessageBox.Show("Cannot currently communicate with the SmarterPing service.  " +
                                "Please ensure that the service is installed and started.\r\n\r\n" +
                                "To install the service, use the Install.bat file.");
            }
            ApplyStartupModeButton.Enabled = false;
        }

        private void ApplyStartupModeButton_Click(object sender, EventArgs e)
        {
            try
            {
                var f = new
                    RegistryPermission(RegistryPermissionAccess.AllAccess,
                        @"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SmarterPing");
                var rk = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\SmarterPing", true);
                switch (StartupModeDropdownList.SelectedIndex)
                {
                    case 0:
                        rk.SetValue("Start", 2);
                        break;
                    case 1:
                        rk.SetValue("Start", 3);
                        break;
                    case 2:
                        rk.SetValue("Start", 4);
                        break;
                }
                rk.Close();
                ApplyStartupModeButton.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void StartServiceButton_Click(object sender, EventArgs e)
        {
            ServiceController service = null;
            try
            {
                service = new ServiceController("SmarterPing");
                service.Start();
            }
            catch
            {
                MessageBox.Show("There was an error trying to start the service SmarterPing.");
            }
            finally
            {
                if (service != null)
                {
                    service.Close();
                    service.Dispose();
                }
            }
        }

        private void StopServiceButton_Click(object sender, EventArgs e)
        {
            ServiceController service = null;
            try
            {
                service = new ServiceController("SmarterPing");
                service.Stop();
            }
            catch
            {
                MessageBox.Show("There was an error trying to stop the service SmarterPing.");
            }
            finally
            {
                if (service != null)
                {
                    service.Close();
                    service.Dispose();
                }
            }
        }

        private void ButtonOK_Click(object sender, EventArgs e)
        {
            try
            {
                string urlRemoting = "tcp://localhost:50004/SmarterPingFunction";
                var funcs = (ISmarterPingFunctions) (Activator.GetObject(typeof (ISmarterPingFunctions), urlRemoting));
                var props = ChannelServices.GetChannelSinkProperties(funcs);
                props["timeout"] = 30 /*sec*/*1000 /*ms*/;
                funcs.SetVariable("interval_minutes", IntervalMinutes.ToString());
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error communicating with the SmarterPing Service.  Please ensure that the service is currently running.");
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void ProcessStatusTimer_Tick(object sender, EventArgs e)
        {
            ServiceController service = null;

            try
            {
                service = new ServiceController("SmarterPing");
                switch (service.Status)
                {
                    case ServiceControllerStatus.ContinuePending:
                        CurrentStatus.Text = "Continuing...";
                        StartServiceButton.Enabled = false;
                        StopServiceButton.Enabled = false;
                        break;
                    case ServiceControllerStatus.Paused:
                        CurrentStatus.Text = "Paused";
                        StartServiceButton.Enabled = true;
                        StopServiceButton.Enabled = false;
                        break;
                    case ServiceControllerStatus.PausePending:
                        CurrentStatus.Text = "Pausing...";
                        StartServiceButton.Enabled = false;
                        StopServiceButton.Enabled = false;
                        break;
                    case ServiceControllerStatus.Running:
                        CurrentStatus.Text = "Running";
                        StartServiceButton.Enabled = false;
                        StopServiceButton.Enabled = true;
                        break;
                    case ServiceControllerStatus.StartPending:
                        CurrentStatus.Text = "Starting...";
                        StartServiceButton.Enabled = false;
                        StopServiceButton.Enabled = false;
                        break;
                    case ServiceControllerStatus.Stopped:
                        CurrentStatus.Text = "Stopped";
                        StartServiceButton.Enabled = true;
                        StopServiceButton.Enabled = false;
                        break;
                    case ServiceControllerStatus.StopPending:
                        CurrentStatus.Text = "Stopping...";
                        StartServiceButton.Enabled = false;
                        StopServiceButton.Enabled = false;
                        break;
                }
            }
            catch
            {
                CurrentStatus.Text = "Unavailable";
            }
            finally
            {
                if (service != null)
                {
                    service.Close();
                    service.Dispose();
                }
            }
        }
    }
}
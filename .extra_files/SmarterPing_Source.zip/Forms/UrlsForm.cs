﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Windows.Forms;
using SmarterPing.Interfaces;

namespace SmarterPing.Forms
{
    public partial class UrlsForm : Form
    {
        public UrlsForm()
        {
            InitializeComponent();
        }

        public List<string> Urls
        {
            get
            {
                var items = from s in UrlListTextbox.Text.Split(new[] {'\r', '\n'}, StringSplitOptions.RemoveEmptyEntries)
                            select s.Trim();

                var urls = from s in items
                           select s.StartsWith("http://", StringComparison.CurrentCultureIgnoreCase) ||
                                  s.StartsWith("https://", StringComparison.CurrentCultureIgnoreCase)
                                      ? s
                                      : "http://" + s;

                return urls.OrderBy(p => p).ToList();
            }
        }

        private void UrlsForm_Load(object sender, EventArgs e)
        {
            UrlListTextbox.Text = "";
            try
            {
                string urlRemoting = "tcp://localhost:50004/SmarterPingFunction";
                var funcs = (ISmarterPingFunctions) (Activator.GetObject(typeof (ISmarterPingFunctions), urlRemoting));
                var props = ChannelServices.GetChannelSinkProperties(funcs);
                props["timeout"] = 30 /*sec*/*1000 /*ms*/;
                var result = funcs.GetUrls();

                UrlListTextbox.Text = "";
                foreach (var item in result.Urls)
                {
                    string URL = item.Url.Trim();
                    if (UrlListTextbox.Text.Length > 0)
                        UrlListTextbox.Text += "\r\n";
                    UrlListTextbox.Text += URL;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Cannot currently communicate with the SmarterPing service.  Please ensure that the service is started.\r\n\r\nTo install the service, use the Install.bat file.");
            }
        }

        private void ButtonOK_Click(object sender, EventArgs e)
        {
            try
            {
                string urlRemoting = "tcp://localhost:50004/SmarterPingFunction";
                var funcs = (ISmarterPingFunctions) (Activator.GetObject(typeof (ISmarterPingFunctions), urlRemoting));
                var props = ChannelServices.GetChannelSinkProperties(funcs);
                props["timeout"] = 30 /*sec*/*1000 /*ms*/;
                funcs.SetUrls(Urls);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error communicating with the SmarterPing Service.  Please ensure that the service is currently running.");
            }
            DialogResult = DialogResult.OK;
            Close();
        }

        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
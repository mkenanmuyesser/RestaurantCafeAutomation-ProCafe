﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Windows.Forms;
using SmarterPing.Forms;
using SmarterPing.Framework;

namespace SmarterPing
{
    internal static class Program
    {
        [DllImport("kernel32.dll")]
        private static extern bool AllocConsole();

        [DllImport("kernel32.dll")]
        private static extern bool AttachConsole(int pid);

        [DllImport("kernel32.dll")]
        private static extern int FreeConsole();

        private static void Main(string[] args)
        {
            try
            {
                // if install was a command line flag, then run the installer at runtime.
                if (args.Contains("-install", StringComparer.InvariantCultureIgnoreCase))
                {
                    if (!AttachConsole(-1))
                        AllocConsole();
                    Console.WriteLine();
                    ConsoleHarness.WriteToConsole(ConsoleColor.Yellow, "Installing SmarterPing Service...");
                    WindowsServiceInstaller.RuntimeInstall<SmarterPingServiceImplementation>();
                    ConsoleHarness.WriteToConsole(ConsoleColor.Yellow, "Starting SmarterPing Service...");
                    try
                    {
                        using (var service = new ServiceController("SmarterPing"))
                            service.Start();
                    }
                    catch
                    {
                        ConsoleHarness.WriteToConsole(ConsoleColor.Red, "There was an error trying to start the service SmarterPing.");
                    }
                    ConsoleHarness.WriteToConsole(ConsoleColor.Yellow, "Install Complete");
                    FreeConsole();
                }

                // if uninstall was a command line flag, run uninstaller at runtime.
                else if (args.Contains("-uninstall", StringComparer.InvariantCultureIgnoreCase))
                {
                    if (!AttachConsole(-1))
                        AllocConsole();
                    Console.WriteLine();
                    ConsoleHarness.WriteToConsole(ConsoleColor.Yellow, "Stopping SmarterPing Service...");
                    try
                    {
                        using (var service = new ServiceController("SmarterPing"))
                            service.Stop();
                    }
                    catch
                    {
                        MessageBox.Show("There was an error trying to stop the service SmarterPing.");
                    }
                    ConsoleHarness.WriteToConsole(ConsoleColor.Yellow, "Uninstalling SmarterPing Service...");
                    WindowsServiceInstaller.RuntimeUnInstall<SmarterPingServiceImplementation>();
                    ConsoleHarness.WriteToConsole(ConsoleColor.Yellow, "Uninstall Complete");
                    FreeConsole();
                }

                // otherwise, fire up the service as either console or windows service based on UserInteractive property.
                else
                {
                    var implementation = new SmarterPingServiceImplementation();

                    // if started from console, file explorer, etc, run as console app.
                    if (Environment.UserInteractive)
                    {
                        try
                        {
                            bool runService = args.Contains("-noservice", StringComparer.InvariantCultureIgnoreCase);
                            if (runService)
                            {
                                implementation.OnStart(args);
                                Application.Run(new MainForm());
                                implementation.OnStop();
                                implementation.OnShutdown();
                            }
                            else
                                Application.Run(new MainForm());
                        }
                        catch
                        {
                        }
                    }

                    // otherwise run as a windows service
                    else
                    {
                        ServiceBase.Run(new WindowsServiceHarness(implementation));
                    }
                }
            }

            catch (Exception ex)
            {
                ConsoleHarness.WriteToConsole(ConsoleColor.Red, "An exception occurred in Main(): {0}", ex);
            }
        }
    }
}
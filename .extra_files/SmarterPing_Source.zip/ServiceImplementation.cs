﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.ServiceProcess;
using SmarterPing.Framework;
using SmarterPing.Service;

namespace SmarterPing
{
    [WindowsService("SmarterPing",
        DisplayName = "SmarterPing",
        Description = "HTTP Keep-Alive service that pings websites on a regular frequency",
        EventLogSource = "SmarterPing",
        StartMode = ServiceStartMode.Automatic)]
    public class SmarterPingServiceImplementation : IWindowsService
    {
        public static TcpChannel RemotingChannelTcp;
        public static UrlPingThread PingThread = new UrlPingThread();
        public static Settings settings = new Settings();
        public static string SettingsFilename = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "SmarterPing.ini");

        #region IWindowsService Members

        /// <summary>
        ///   Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        /// <filterpriority>2</filterpriority>
        public void Dispose()
        {
        }

        /// <summary>
        ///   This method is called when the service gets a request to start.
        /// </summary>
        /// <param name = "args">Any command line arguments</param>
        public void OnStart(string[] args)
        {
            try
            {
                settings = Settings.Load(SettingsFilename);
            }
            catch
            {
                settings = new Settings();
            }

            PingThread.URLS = settings.Urls;
            PingThread.DelaySeconds = settings.IntervalMinutes*60;
            PingThread.Start();

            if (RemotingChannelTcp == null)
            {
                var remotingPropertiesTcp = new ListDictionary
                                                {
                                                    {"name", string.Empty},
                                                    {"port", 50004},
                                                    {"rejectRemoteRequests", true}
                                                };
                RemotingChannelTcp = new TcpChannel(remotingPropertiesTcp, new BinaryClientFormatterSinkProvider(), new BinaryServerFormatterSinkProvider());
                ChannelServices.RegisterChannel(RemotingChannelTcp, false);
            }

            try
            {
                RemotingConfiguration.RegisterWellKnownServiceType(typeof (SmarterPingFunction), "SmarterPingFunction", WellKnownObjectMode.Singleton);
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        ///   This method is called when the service gets a request to stop.
        /// </summary>
        public void OnStop()
        {
            try
            {
                ChannelServices.UnregisterChannel(RemotingChannelTcp);
            }
            catch
            {
            }
            PingThread.Stop();
        }

        /// <summary>
        ///   This method is called when a service gets a request to pause, 
        ///   but not stop completely.
        /// </summary>
        public void OnPause()
        {
            PingThread.Stop();
        }

        /// <summary>
        ///   This method is called when a service gets a request to resume 
        ///   after a pause is issued.
        /// </summary>
        public void OnContinue()
        {
            PingThread.Start();
        }

        /// <summary>
        ///   This method is called when the machine the service is running on
        ///   is being shutdown.
        /// </summary>
        public void OnShutdown()
        {
        }

        /// <summary>
        ///   This method is called when a custom command is issued to the service.
        /// </summary>
        /// <param name = "command">The command identifier to execute.</param>
        public void OnCustomCommand(int command)
        {
        }

        #endregion
    }
}
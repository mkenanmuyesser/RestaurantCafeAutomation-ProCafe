﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SmarterPing.Service
{
    public class Settings
    {
        public int IntervalMinutes = 10;
        public List<string> Urls = new List<string>();

        public void Save(string filename)
        {
            using (var sw = new StreamWriter(filename, false))
            {
                sw.WriteLine("[VARIABLES]");
                sw.WriteLine("interval_minutes=" + IntervalMinutes);
                foreach (string s in Urls)
                    sw.WriteLine("url=" + s);
                sw.Close();
            }
        }

        public static Settings Load(string filename)
        {
            var retval = new Settings();

            var lines = File.ReadAllLines(filename);
            foreach (string line in lines)
            {
                var parts = line.Split(new[] {'='}, 2);
                if (parts.Length != 2)
                    continue;

                if (parts[0].ToUpper() == "INTERVAL_MINUTES")
                {
                    int tempInterval;
                    if (int.TryParse(parts[1], out tempInterval))
                        retval.IntervalMinutes = tempInterval;
                }
                else if (parts[0].ToUpper() == "URL" && parts[1].Trim().Length > 0)
                    retval.Urls.Add(parts[1].Trim());
            }

            return retval;
        }
    }
}
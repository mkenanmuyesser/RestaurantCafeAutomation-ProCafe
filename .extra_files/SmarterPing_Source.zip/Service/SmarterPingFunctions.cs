﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using SmarterPing.Interfaces;

namespace SmarterPing.Service
{
    public class SmarterPingFunction : MarshalByRefObject, ISmarterPingFunctions
    {
        #region ISmarterPingFunctions Members

        public SmarterPingFunctionResult SetUrls(List<string> URLs)
        {
            var retval = new SmarterPingFunctionResult();

            SmarterPingServiceImplementation.settings.Urls = URLs;
            SmarterPingServiceImplementation.settings.Save(SmarterPingServiceImplementation.SettingsFilename);
            SmarterPingServiceImplementation.PingThread.URLS = URLs;

            retval.FunctionSucceeded = true;
            retval.ResultMessage = "URL list has been updated";
            SmarterPingServiceImplementation.PingThread.PingNow();

            return retval;
        }

        public SmarterPingFunctionResult SetVariable(string variable, string val)
        {
            var retval = new SmarterPingFunctionResult();

            switch (variable.ToUpper())
            {
                case "INTERVAL_MINUTES":
                    try
                    {
                        SmarterPingServiceImplementation.settings.IntervalMinutes = Convert.ToInt32(val);
                        if (SmarterPingServiceImplementation.settings.IntervalMinutes < 1)
                            SmarterPingServiceImplementation.settings.IntervalMinutes = 1;
                        SmarterPingServiceImplementation.settings.Save(SmarterPingServiceImplementation.SettingsFilename);
                        SmarterPingServiceImplementation.PingThread.DelaySeconds = SmarterPingServiceImplementation.settings.IntervalMinutes*60;
                        retval.FunctionSucceeded = true;
                        retval.ResultMessage = "Variable has been updated";
                    }
                    catch
                    {
                        retval.FunctionSucceeded = false;
                        retval.ResultMessage = "Variable must be a positive integer";
                    }
                    break;
                default:
                    retval.FunctionSucceeded = false;
                    retval.ResultMessage = "Unknown variable: " + variable;
                    break;
            }

            return retval;
        }

        public SmarterPingFunctionResult GetVariable(string variable)
        {
            var retval = new SmarterPingFunctionResult();

            switch (variable.ToUpper())
            {
                case "INTERVAL_MINUTES":
                    retval.FunctionSucceeded = true;
                    retval.ResultMessage = SmarterPingServiceImplementation.settings.IntervalMinutes.ToString();
                    break;
                default:
                    retval.FunctionSucceeded = false;
                    retval.ResultMessage = "Unknown variable: " + variable;
                    break;
            }

            return retval;
        }

        public SmarterPingUrlListResult GetUrls()
        {
            var retval = new SmarterPingUrlListResult();

            foreach (string URL in SmarterPingServiceImplementation.settings.Urls)
            {
                var item = new UrlResult {Url = URL};
                lock (SmarterPingServiceImplementation.PingThread.LastPingTimes)
                {
                    if (SmarterPingServiceImplementation.PingThread.LastPingTimes.ContainsKey(URL) &&
                        SmarterPingServiceImplementation.PingThread.LastPingResults.ContainsKey(URL))
                    {
                        item.LastPing = SmarterPingServiceImplementation.PingThread.LastPingTimes[URL];
                        item.LastPingSuceeded = SmarterPingServiceImplementation.PingThread.LastPingResults[URL];
                    }
                }
                retval.Urls.Add(item);
            }

            retval.FunctionSucceeded = true;
            retval.ResultMessage = "Success";

            return retval;
        }

        #endregion
    }
}
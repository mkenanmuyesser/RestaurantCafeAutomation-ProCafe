﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;

namespace SmarterPing.Service
{
    public class UrlPingThread
    {
        #region Delegates

        public delegate void URLPingedHandler(object sender, URLPingedEventArgs args);

        #endregion

        private readonly object thdLock = new object();

        public int DelaySeconds = 60*10;
        public Dictionary<string, bool> LastPingResults = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, DateTime> LastPingTimes = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        public bool Running;
        private bool interrupt;
        private Thread thd;
        private List<string> urls = new List<string>();

        public List<string> URLS
        {
            get
            {
                lock (urls)
                {
                    return new List<string>(urls);
                }
            }
            set
            {
                lock (urls)
                {
                    urls = new List<string>(value);
                }
                lock (LastPingTimes)
                {
                    LastPingTimes.Clear();
                    LastPingResults.Clear();
                }
            }
        }

        public event URLPingedHandler URLPinged;

        public void PingNow()
        {
            interrupt = true;
        }

        public void Start()
        {
            lock (thdLock)
            {
                InternalStop();
                thd = new Thread(ThreadLoop) {Name = "URLPingThread", IsBackground = true};
                thd.Start();
            }
        }

        public void Stop()
        {
            lock (thdLock)
            {
                InternalStop();
            }
        }

        private void InternalStop()
        {
            if (thd == null)
                return;
            try
            {
                thd.Abort();
                while (Running)
                    Thread.Sleep(50);
            }
            catch
            {
            }
            Running = false;
            thd = null;
        }

        public static bool TryUrl(string url)
        {
            try
            {
                var req = (HttpWebRequest) WebRequest.Create(url);
                var resp = (HttpWebResponse) req.GetResponse();
                var rs = resp.GetResponseStream();
                if (rs == null)
                    return false;
                var sr = new StreamReader(rs);
                sr.ReadToEnd();
                sr.Close();
                resp.Close();
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void ThreadLoop()
        {
            Running = true;
            try
            {
                while (true)
                {
                    // Ping sites in list
                    foreach (string URL in URLS)
                    {
                        string URLToHit = URL.Trim();
                        bool success = TryUrl(URLToHit);

                        lock (LastPingTimes)
                        {
                            LastPingTimes[URLToHit] = DateTime.Now;
                            LastPingResults[URLToHit] = success;
                        }

                        if (URLPinged != null)
                        {
                            var args = new URLPingedEventArgs {URL = URLToHit, Succeeded = success, DateOfPing = DateTime.Now};
                            URLPinged(this, args);
                        }
                    }

                    // Wait for next iteration
                    for (int i = 0; i < DelaySeconds*10; i++)
                    {
                        if (interrupt)
                            break;
                        Thread.Sleep(100);
                    }
                    interrupt = false;
                }
            }
            finally
            {
                Running = false;
            }
        }

        #region Nested type: URLPingedEventArgs

        public class URLPingedEventArgs : EventArgs
        {
            public DateTime DateOfPing = DateTime.Now;
            public bool Succeeded;
            public string URL = "";
        }

        #endregion
    }
}
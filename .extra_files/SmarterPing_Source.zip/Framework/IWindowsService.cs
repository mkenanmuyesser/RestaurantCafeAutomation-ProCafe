﻿/*
    SmarterPing Http Keep-Alive Utility
    Copyright (C) 2003-2011 SmarterTools Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;

namespace SmarterPing.Framework
{
    /// <summary>
    /// The interface that any windows service should implement to be used
    /// with the GenericWindowsService executable.
    /// </summary>
    public interface IWindowsService : IDisposable
    {
        /// <summary>
        /// This method is called when the service gets a request to start.
        /// </summary>
        /// <param name="args">Any command line arguments</param>
        void OnStart(string[] args);

        /// <summary>
        /// This method is called when the service gets a request to stop.
        /// </summary>
        void OnStop();

        /// <summary>
        /// This method is called when a service gets a request to pause, 
        /// but not stop completely.
        /// </summary>
        void OnPause();

        /// <summary>
        /// This method is called when a service gets a request to resume 
        /// after a pause is issued.
        /// </summary>
        void OnContinue();

        /// <summary>
        /// This method is called when the machine the service is running on
        /// is being shutdown.
        /// </summary>
        void OnShutdown();

        /// <summary>
        /// This method is called when a custom command is issued to the service.
        /// </summary>
        /// <param name="command">The command identifier to execute.</param >
        void OnCustomCommand(int command);
    }
}
